[Portugu�s]
- Aqui � o seu Custom LESS! Caso queira editar o less, fa�a isso atrav�s dos arquivos desta pasta.
- N�o se esque�a de:
	Criar pasta com o nome do cliente/deal atrav�s do File Manager.
	Fazer upload das imagens bg.jpg, array-add.png, array-remove.png e logo.png dentro da pasta criada (obrigat�rio!!).

[Espanhol]

[English]